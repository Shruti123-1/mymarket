from re import template
from django.urls import path
from front import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import messages, auth
from django.contrib.auth import views as auth_views
from front.forms import LoginForm , NewPasswordChangeForm, MyPasswordResetForm, MySetPasswordForm

urlpatterns = [
    # path('', views.home),
    path('', views.ProductView.as_view(),name="home"),

    # path('product-detail/', views.product_detail, name='product-detail'),
    path('product-detail/<int:pk>', views.ProductDetailView.as_view(),name='productdetail'),

    # path('customerregistration',views.customerregistration,name="customerregistration"),
    path('customerregistration',views.CustomerRegistrationView.as_view(),name='customerregistration'),
    
    # path('login',views.login,name="login"),
    path('login', auth_views.LoginView.as_view(next_page='profile', template_name='app/login.html',authentication_form=LoginForm), name='login'),

    # path('logout',views.logout,name="logout"),
    path('logout', auth_views.LogoutView.as_view(next_page='login'),name='logout'),

    path('profile', views.ProfileView.as_view(),name="profile"),

    # path('address',views.address,name="address"),
    path('address', views.AddressView.as_view(),name='address'),

    path('orders',views.orders,name="orders"),

    path('addtocart',views.addtocart,name="addtocart"),

    path('cart', views.show_cart, name='show_cart'),
    path('colorpic', views.colorpic,name='colorpic'),

    path('checkout',views.checkout,name="checkout"),
    path('paymentdone', views.paymentdone,name='paymentdone'),

    path('mobile',views.mobile,name='mobile'),

    path('mobile/<slug:data>',views.mobile,name='mobiledata'),

    # path('changepassword',views.changepassword,name='changepassword'),
    path('passwordchange', auth_views.PasswordChangeView.as_view(template_name='app/passwordchange.html', form_class=NewPasswordChangeForm, success_url='/passwordchangedone/'),name='passwordchange'),

    path('passwordchangedone/',auth_views.PasswordChangeView.as_view(template_name='app/passwordchangedone.html'),name='passwordchangedone'),

    path('password_reset/', auth_views.PasswordResetView.as_view(template_name='app/password_reset.html', form_class=MyPasswordResetForm),name='password_reset'),

    path('password_reset_done', auth_views.PasswordResetDoneView.as_view(template_name='app/password_reset_done.html'), name='password_reset_done'),
    
    path('password_reset_confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='app/password_reset_confirm.html', form_class=MySetPasswordForm), name='password_reset_confirm'),

    path('password_reset_complete/', auth_views.PasswordResetCompleteView.as_view(template_name='app/password_reset_complete.html'),name='password_reset_complete'),
 
    path('pluscart/',views.plus_cart),
    path('minuscart/',views.minus_cart),
    path('remove_cart', views.remove_cart),
    path('imageuploader',views.imageuploader,name="imageuploader"),
] + static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)

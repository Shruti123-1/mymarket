from ast import Delete
from cmath import log
from distutils.log import Log
from itertools import product
from math import prod
from unicodedata import category
from django.http import JsonResponse
from django.shortcuts import render , redirect, HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages, auth
from front.models import *
from django.views import View
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from .forms import CustomerRegistrationForm, CustomerProfileForm, ImageForm
from django.http import JsonResponse
from django.db.models import Q
from django.core.paginator import Paginator

# from django.contrib.auth import PasswordChangeForm
# Create your views here.
# def home(request):
#  return render(request, 'app/home.html')

# def product_detail(request):
#  return render(request, 'app/productdetail.html')

def mobile(request , data = None):
    total_cart_item = len(Cart.objects.filter(user=request.user))
    if data == None:
        mobile = Product.objects.filter(category='M').order_by('id')
        paginator = Paginator(mobile, 3)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        return render(request, 'app/mobile.html'  , {'mobile': page_obj, 'total_cart_item' : total_cart_item})
    elif data == 'Moto' or data == 'Samsung' or data == 'Redmi':
        mobile = Product.objects.filter(category = 'M').filter(brand=data)
        paginator = Paginator(mobile, 3)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        return render(request, 'app/mobile.html'  , {'mobile': page_obj , 'total_cart_item' : total_cart_item})
       
    elif data == 'below':
        mobile = Product.objects.filter(category = 'M').filter(discounted_price__gt = 500)
        paginator = Paginator(mobile, 3)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        return render(request, 'app/mobile.html'  , {'mobile': page_obj , 'total_cart_item' : total_cart_item})
    elif data == 'above':
        mobile = Product.objects.filter(category = 'M').filter(discounted_price__lt = 500)
        paginator = Paginator(mobile, 3)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        return render(request, 'app/mobile.html'  , {'mobile': page_obj , 'total_cart_item' :total_cart_item})
    else:
        mobile = Product.objects.filter(category='M')
        paginator = Paginator(mobile, 3)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        return render(request, 'app/mobile.html'  , {'mobile': page_obj , 'total_cart_item' : total_cart_item})

class ProductDetailView(View):
    
    def get(self,request,pk):
        product = Product.objects.get(id=pk)
        
        item_already_in_cart = False
        if request.user.is_authenticated:
            total_cart_item = len(Cart.objects.filter(user=request.user))
            item_already_in_cart = Cart.objects.filter(Q(product=product.id) & Q(user=request.user)).exists()
        
            return render (request, 'app/productdetail.html', 
            {
                'product' : product,
                'item_already_in_cart' : item_already_in_cart,
                'total_cart_item' : total_cart_item
            })
        else:
             return render (request, 'app/productdetail.html', 
            {
                'product' : product,
                'item_already_in_cart' : item_already_in_cart
                
            })


class ProductView(View):
    def get(self,request):
        topwears = Product.objects.filter(category = 'TW')
        bottomwears = Product.objects.filter(category = 'BW')
        mobiles = Product.objects.filter(category = 'M')
        if request.user.is_authenticated:
            total_cart_item = len(Cart.objects.filter(user=request.user))

            return render(request, 'app/home.html', 
            {
                'topwears' :topwears , 'bottomwears': bottomwears, 'mobiles' : mobiles , 'total_cart_item' :total_cart_item
            })
        else:
            return render(request, 'app/home.html', 
            {
                'topwears' :topwears , 'bottomwears': bottomwears, 'mobiles' : mobiles 
            })



# def customerregistration(request):
#     # print("aa")
#     if request.method == 'POST':
#         entered_username = request.POST['name']
#         entered_email = request.POST['email']
#         entered_password = request.POST['password']
#         entered_password2 = request.POST['password2']

#         if entered_password == entered_password2:
#             if User.objects.filter(username=entered_username).exists():
#                 messages.info(request, "Username already exists")
#                 return redirect ("customerregistration")
#             elif User.objects.filter(email=entered_email).exists():
#                 messages.info(request, "Email already in use")
#                 return redirect ("customerregistration")
#             else:
#                 user = User.objects.create_user(username=entered_username, email = entered_email, password = entered_password)
#             customer = Customer(user=user, name= entered_username,email= entered_email )
#             # print(customer)
#             customer.save()

#             return redirect("profile")
#         else:
#             messages.info(request, "Your Passwords don't match. Try again")
#             return redirect("customerregistration")
#     else:
        
#         return render(request, 'app/customerregistration.html')

class CustomerRegistrationView(View):
    def get(self , request):
        form = CustomerRegistrationForm()
        return render(request, 'app/customerregistration.html' , {'form' : form})
    def post(self,request):
        print(request.POST)
        form = CustomerRegistrationForm(request.POST)
        
        
        if form.is_valid():
            # print(form)
            messages.success(request, 'Congratulations !, Registered Successfully')
            form.save()
        return render(request, 'app/customerregistration.html' , {'form' : form})

def login(request):
    if request.method == 'POST':
        entered_username = request.POST['username']
        entered_password = request.POST['password']

        user = auth.authenticate(request, username=entered_username, password=entered_password)

        print(user)

        if user is None:
            messages.info(request, "Invalid credentials. Please try again")
            return redirect("login")
            
        else:
            auth.login(request, user)
            return redirect("profile")

 
    else: 
        return render(request, 'app/login.html')



def logout(request):
    auth.logout(request)
    return redirect('/')

# def changepassword(request):
#     return render(request, 'app/changepassword.html')

@method_decorator(login_required,name='dispatch')
class ProfileView(View):
    def get(self,request):
        total_cart_item = len(Cart.objects.filter(user=request.user))
        form = CustomerProfileForm
        return render(request, 'app/profile.html' ,{'form' : form, 'active' : 'btn-primary' , 'total_cart_item' :total_cart_item})

    def post(self, request):
        form = CustomerProfileForm(request.POST)
        total_cart_item = len(Cart.objects.filter(user=request.user))
        if form.is_valid():
            user = request.user
            name = form.cleaned_data['name']
            locality = form.cleaned_data['locality']
            city = form.cleaned_data['city']
            state = form.cleaned_data['state']
            zipcode = form.cleaned_data['zipcode']
            reg = Customer(user = user, name = name,locality=locality, city=city, state= state, zipcode=zipcode, )
            reg.save()
            messages.success(request, 'Congratulations !! Profile Updated Successfully')
            return render(request, 'app/profile.html' , {'form' : form, 'active' : 'btn-primary' , 'total_cart_item' :total_cart_item})

@method_decorator(login_required,name='dispatch')
class AddressView(View):
    def get(self,request):
        total_cart_item = len(Cart.objects.filter(user=request.user))
        # address = CustomerProfileForm
        address = Customer.objects.filter(user=request.user)
        return render(request,'app/address.html',{'address' : address, 'active' : 'btn-primary' , 'total_cart_item' :total_cart_item})



@login_required(login_url="login")
def orders(request):
    order = OrderPlaced.objects.filter(user=request.user)
    total_cart_item = len(Cart.objects.filter(user=request.user))
    return render(request, 'app/orders.html', {'order' : order, 'active' : 'btn-primary','total_cart_item' : total_cart_item})

@login_required(login_url="login")
def addtocart(request):
    user = request.user
    product_id = request.GET.get('prod_id')
    product = Product.objects.get(id=product_id)
    Cart(user=user,product=product).save()
    # cart_product = Cart.objects.filter(user)
    # if request.user.is_authenticated:
    return redirect('/cart')

@login_required(login_url="login")
def show_cart(request):
    if request.user.is_authenticated:
        user = request.user
        total_cart_item = len(Cart.objects.filter(user=user))
        cart = Cart.objects.filter(user=user)
        amount = 0.0
        shipping_amount = 70.0
        total_amount = 0.0
        cart_product = [p for p in Cart.objects.all() if p.user == user]
        if cart_product:
            for p in cart_product:
                tempamount = (p.quantity * p.product.selling_price)
                amount += tempamount
                totalamount = amount + shipping_amount
            return render(request, 'app/addtocart.html', {'cart' : cart, 'totalamount' : totalamount, 'amount': amount,'total_cart_item':total_cart_item})

        else:   
            return render (request, 'app/empty_cart.html')

@login_required(login_url="login")
def plus_cart(request):
    if request.method == 'GET':
        user = request.user
        prod_id = request.GET['prod_id']
        print(prod_id)
        c = Cart.objects.get(Q(product=prod_id) & Q(user = user))
        c.quantity += 1
        c.save()
        amount = 0.0
        shipping_amount = 70.0
        # total_amount = 0.0
        cart_product = [p for p in Cart.objects.all() if p.user == user]
        if cart_product:
            for p in cart_product:
                tempamount = (p.quantity * p.product.selling_price)
                amount += tempamount
                # totalamount = amount + shipping_amount

        data = {
            'quantity' : c.quantity,
            'amount' : amount,
            'totalamount' : amount + shipping_amount
        }
        return JsonResponse(data)



@login_required(login_url="login")
def minus_cart(request):
    if request.method == 'GET':
        user = request.user
        prod_id = request.GET['prod_id']
        print(prod_id)
        c = Cart.objects.get(Q(product=prod_id) & Q(user = user))
        c.quantity -= 1
        c.save()
        amount = 0.0
        shipping_amount = 70.0
        # total_amount = 0.0
        cart_product = [p for p in Cart.objects.all() if p.user == user]
        if cart_product:
            for p in cart_product:
                tempamount = (p.quantity * p.product.selling_price)
                amount += tempamount
                # totalamount = amount + shipping_amount

        data = {
            'quantity' : c.quantity,
            'amount' : amount,
            'totalamount' : amount + shipping_amount
        }
        return JsonResponse(data)


@login_required(login_url="login")
def remove_cart(request):
    if request.method == 'GET':
        user = request.user
        prod_id = request.GET['prod_id']
        print(prod_id)
        c = Cart.objects.get(Q(product=prod_id) & Q(user = user))
        c.delete()
        
        amount = 0.0
        shipping_amount = 70.0
        # total_amount = 0.0
        cart_product = [p for p in Cart.objects.all() if p.user == user]
        if cart_product:
            for p in cart_product:
                tempamount = (p.quantity * p.product.selling_price)
                amount += tempamount
                # totalamount = amount + shipping_amount

        data = {
            # 'quantity' : c.quantity,
            'amount' : amount,
            'totalamount' :  amount + shipping_amount

        }
        return JsonResponse(data)


@login_required(login_url="login")
def checkout(request):
    user = request.user
    total_cart_item = len(Cart.objects.filter(user=user))
    add = Customer.objects.filter(user=user)
    cart_items = Cart.objects.filter(user=user)
    amount = 0.0
    shipping_amount = 70.0
    totalamount = 0.0
    cart_product = [p for p in Cart.objects.all() if p.user == user]
    if cart_product:
        for p in cart_product:
            tempamount = (p.quantity * p.product.selling_price)
            amount += tempamount
            totalamount = amount + shipping_amount
    return render(request, 'app/checkout.html', {'add': add, 'totalamount':totalamount, 'cart_items': cart_items,'total_cart_item':total_cart_item})


@login_required(login_url="login")
def paymentdone(request):
    user = request.user
    custid = request.GET.get('custid')
    # print(custid)
    customer = Customer.objects.get(id=custid)
    cart = Cart.objects.filter(user=user)
    for c in cart:
        OrderPlaced(user=user, customer=customer,product=c.product, quantity=c.quantity).save()
        c.delete()
    return redirect('orders')    






# def signup(request):
#     if request.method == 'POST':
#         entered_name = request.POST['name']
#         entered_username = request.POST['username']
#         entered_email = request.POST['email']
#         entered_password = request.POST['password']
#         entered_password2 = request.POST['password2']

#         if entered_password == entered_password2:
#             if User.objects.filter(username=entered_username).exists():
#                 messages.info(request, "Username already exists")
#                 return redirect ("signup")
#             elif User.objects.filter(email=entered_email).exists():
#                 messages.info(request, "Email already in use")
#                 return redirect ("signup")
#             else:
#                 user = User.objects.create_user(username=entered_username, email=entered_email, first_name = entered_name, password = entered_password)

#                 return redirect("login")
#         else:
#             messages.info(request, "Your Passwords don't match. Try again")
#             return redirect("signup")
#     else:
        
#         return render(request, 'signup.html')


def imageuploader(request):
    if request.method == 'POST':
        form = ImageForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
    form = ImageForm()
    img = Image.objects.all()
    return render(request,'app/imageuploader.html', {'form' : form, 'img' : img})

def colorpic(request):
    return render(request,'app/colorpic.html')
